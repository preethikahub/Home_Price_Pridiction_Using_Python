/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  BarChart, Bar, ScatterChart, Scatter, ZAxis, Cell, PieChart, Pie,
  AreaChart, Area
} from 'recharts';
import { 
  Home, 
  Database, 
  BarChart3, 
  Eraser, 
  Wand2, 
  Cpu, 
  CheckCircle2, 
  Eye, 
  Calculator, 
  FileText,
  ChevronRight,
  Code2,
  Info,
  TrendingUp,
  MapPin,
  Layers,
  Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { cn } from '@/src/lib/utils';

// --- Mock Data & Constants ---

const CALIFORNIA_HOUSING_SAMPLE = [
  { id: 1, MedInc: 8.32, HouseAge: 41, AveRooms: 6.98, AveBedrms: 1.02, Population: 322, AveOccup: 2.55, Latitude: 37.88, Longitude: -122.23, MedHouseVal: 4.52 },
  { id: 2, MedInc: 8.30, HouseAge: 21, AveRooms: 6.23, AveBedrms: 0.97, Population: 2401, AveOccup: 2.10, Latitude: 37.86, Longitude: -122.22, MedHouseVal: 3.58 },
  { id: 3, MedInc: 7.25, HouseAge: 52, AveRooms: 8.28, AveBedrms: 1.07, Population: 496, AveOccup: 2.80, Latitude: 37.85, Longitude: -122.24, MedHouseVal: 3.52 },
  { id: 4, MedInc: 5.64, HouseAge: 52, AveRooms: 5.81, AveBedrms: 1.07, Population: 558, AveOccup: 2.54, Latitude: 37.85, Longitude: -122.25, MedHouseVal: 3.41 },
  { id: 5, MedInc: 3.84, HouseAge: 52, AveRooms: 6.28, AveBedrms: 1.08, Population: 565, AveOccup: 2.18, Latitude: 37.85, Longitude: -122.25, MedHouseVal: 3.42 },
  { id: 6, MedInc: 4.03, HouseAge: 52, AveRooms: 4.76, AveBedrms: 1.10, Population: 413, AveOccup: 2.13, Latitude: 37.85, Longitude: -122.25, MedHouseVal: 2.69 },
  { id: 7, MedInc: 3.65, HouseAge: 52, AveRooms: 4.93, AveBedrms: 1.04, Population: 1094, AveOccup: 2.00, Latitude: 37.84, Longitude: -122.25, MedHouseVal: 2.99 },
  { id: 8, MedInc: 3.12, HouseAge: 52, AveRooms: 4.78, AveBedrms: 1.06, Population: 1157, AveOccup: 2.14, Latitude: 37.84, Longitude: -122.25, MedHouseVal: 2.41 },
];

const CORRELATION_DATA = [
  { x: 'MedInc', y: 'Price', value: 0.68 },
  { x: 'HouseAge', y: 'Price', value: 0.10 },
  { x: 'AveRooms', y: 'Price', value: 0.15 },
  { x: 'Population', y: 'Price', value: -0.02 },
  { x: 'AveOccup', y: 'Price', value: -0.02 },
  { x: 'Latitude', y: 'Price', value: -0.14 },
];

const MODEL_PERFORMANCE = [
  { name: 'Linear Regression', RMSE: 0.72, R2: 0.61 },
  { name: 'Random Forest', RMSE: 0.50, R2: 0.81 },
  { name: 'XGBoost', RMSE: 0.47, R2: 0.83 },
];

const FEATURE_IMPORTANCE = [
  { feature: 'MedInc', importance: 0.52 },
  { feature: 'AveOccup', importance: 0.14 },
  { feature: 'Latitude', importance: 0.09 },
  { feature: 'Longitude', importance: 0.08 },
  { feature: 'HouseAge', importance: 0.05 },
  { feature: 'AveRooms', importance: 0.04 },
  { feature: 'Population', importance: 0.03 },
  { feature: 'AveBedrms', importance: 0.05 },
];

const ACTUAL_VS_PRED = Array.from({ length: 50 }, (_, i) => ({
  actual: 1 + Math.random() * 4,
  predicted: 1 + Math.random() * 4,
})).map(d => ({ ...d, predicted: d.actual * (0.85 + Math.random() * 0.3) }));

// --- Components ---

const CodeBlock = ({ code, language = 'python' }: { code: string, language?: string }) => (
  <div className="relative group my-4">
    <div className="absolute -top-3 left-4 px-2 py-0.5 bg-zinc-800 text-zinc-400 text-[10px] font-mono uppercase tracking-wider rounded border border-zinc-700 z-10">
      {language}
    </div>
    <pre className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-4 overflow-x-auto font-mono text-sm text-zinc-300 leading-relaxed">
      <code>{code}</code>
    </pre>
  </div>
);

const SectionTitle = ({ icon: Icon, title, subtitle }: { icon: any, title: string, subtitle?: string }) => (
  <div className="mb-8">
    <div className="flex items-center gap-3 mb-2">
      <div className="p-2 bg-orange-500/10 rounded-lg">
        <Icon className="w-6 h-6 text-orange-500" />
      </div>
      <h2 className="text-2xl font-bold text-zinc-100 tracking-tight">{title}</h2>
    </div>
    {subtitle && <p className="text-zinc-400 text-sm ml-11">{subtitle}</p>}
  </div>
);

export default function App() {
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    { id: 0, label: 'Introduction', icon: Info },
    { id: 1, label: 'Dataset Loading', icon: Database },
    { id: 2, label: 'Exploration', icon: BarChart3 },
    { id: 3, label: 'Cleaning', icon: Eraser },
    { id: 4, label: 'Engineering', icon: Wand2 },
    { id: 5, label: 'Development', icon: Cpu },
    { id: 6, label: 'Evaluation', icon: CheckCircle2 },
    { id: 7, label: 'Visualization', icon: Eye },
    { id: 8, label: 'Prediction', icon: Calculator },
    { id: 9, label: 'Final Output', icon: FileText },
  ];

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <SectionTitle 
              icon={Info} 
              title="Project Introduction" 
              subtitle="Predicting California housing prices using regression techniques."
            />
            <div className="prose prose-invert max-w-none text-zinc-300 leading-relaxed">
              <p>
                The goal of this project is to develop a machine learning model that can accurately predict the median house value in California districts. 
                This is a <strong>Regression</strong> problem where we use features like median income, house age, and location to estimate a continuous numerical value.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-8">
                {[
                  { label: 'Target Variable', value: 'MedHouseVal', desc: 'Median house value for California districts (units of $100k)' },
                  { label: 'Features', value: '8 Numerical', desc: 'Income, Age, Rooms, Population, Location, etc.' },
                  { label: 'Algorithms', value: 'LR, RF, XGB', desc: 'Comparing baseline linear models with ensemble methods.' },
                ].map((item, i) => (
                  <div key={i} className="p-4 bg-zinc-900/50 border border-zinc-800 rounded-xl">
                    <div className="text-orange-500 font-bold mb-1">{item.label}</div>
                    <div className="text-xl font-mono text-white mb-2">{item.value}</div>
                    <div className="text-xs text-zinc-500">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        );

      case 1:
        return (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <SectionTitle 
              icon={Database} 
              title="Dataset Loading" 
              subtitle="Importing the California Housing dataset from Scikit-Learn."
            />
            <CodeBlock code={`import pandas as pd
import numpy as np
from sklearn.datasets import fetch_california_housing

# Load the dataset
housing = fetch_california_housing()
df = pd.DataFrame(housing.data, columns=housing.feature_names)
df['MedHouseVal'] = housing.target

print(f"Dataset Shape: {df.shape}")
print(df.head())`} />
            
            <div className="overflow-x-auto border border-zinc-800 rounded-xl">
              <table className="w-full text-left text-sm font-mono">
                <thead className="bg-zinc-900 text-zinc-400 border-bottom border-zinc-800">
                  <tr>
                    <th className="p-3">MedInc</th>
                    <th className="p-3">HouseAge</th>
                    <th className="p-3">AveRooms</th>
                    <th className="p-3">Population</th>
                    <th className="p-3">MedHouseVal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800 text-zinc-300">
                  {CALIFORNIA_HOUSING_SAMPLE.slice(0, 5).map((row) => (
                    <tr key={row.id} className="hover:bg-zinc-900/50 transition-colors">
                      <td className="p-3">{row.MedInc.toFixed(2)}</td>
                      <td className="p-3">{row.HouseAge}</td>
                      <td className="p-3">{row.AveRooms.toFixed(2)}</td>
                      <td className="p-3">{row.Population}</td>
                      <td className="p-3 text-orange-400 font-bold">{row.MedHouseVal.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        );

      case 2:
        return (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
            <SectionTitle 
              icon={BarChart3} 
              title="Data Exploration (EDA)" 
              subtitle="Visualizing distributions and correlations."
            />
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl">
                <h3 className="text-sm font-medium text-zinc-400 mb-6 uppercase tracking-widest">Price Distribution</h3>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={CALIFORNIA_HOUSING_SAMPLE}>
                      <defs>
                        <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                      <XAxis dataKey="id" hide />
                      <YAxis stroke="#52525b" fontSize={12} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px' }}
                        itemStyle={{ color: '#f97316' }}
                      />
                      <Area type="monotone" dataKey="MedHouseVal" stroke="#f97316" fillOpacity={1} fill="url(#colorVal)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl">
                <h3 className="text-sm font-medium text-zinc-400 mb-6 uppercase tracking-widest">Feature Correlation (with Price)</h3>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={CORRELATION_DATA} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" horizontal={false} />
                      <XAxis type="number" domain={[-1, 1]} stroke="#52525b" fontSize={12} />
                      <YAxis dataKey="x" type="category" stroke="#52525b" fontSize={12} width={80} />
                      <Tooltip 
                        cursor={{ fill: '#27272a' }}
                        contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px' }}
                      />
                      <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                        {CORRELATION_DATA.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.value > 0 ? '#f97316' : '#ef4444'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </motion.div>
        );

      case 3:
        return (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <SectionTitle 
              icon={Eraser} 
              title="Data Cleaning" 
              subtitle="Handling missing values and outliers."
            />
            <div className="prose prose-invert max-w-none text-zinc-300">
              <p>Cleaning involves ensuring the data is consistent and free of noise that could mislead the model.</p>
            </div>
            <CodeBlock code={`# Check for missing values
print(df.isnull().sum())

# Handle outliers using IQR method
Q1 = df['MedHouseVal'].quantile(0.25)
Q3 = df['MedHouseVal'].quantile(0.75)
IQR = Q3 - Q1
df = df[~((df['MedHouseVal'] < (Q1 - 1.5 * IQR)) | (df['MedHouseVal'] > (Q3 + 1.5 * IQR)))]

print(f"Cleaned Dataset Shape: {df.shape}")`} />
            <div className="p-4 bg-orange-500/5 border border-orange-500/20 rounded-xl flex items-start gap-4">
              <Info className="w-5 h-5 text-orange-500 mt-1 shrink-0" />
              <div className="text-sm text-zinc-400">
                <strong className="text-zinc-200">Insight:</strong> California housing data is generally clean, but price capping at 5.0 ($500k) is a known characteristic that often requires special handling or removal.
              </div>
            </div>
          </motion.div>
        );

      case 4:
        return (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <SectionTitle 
              icon={Wand2} 
              title="Feature Engineering" 
              subtitle="Scaling and creating new features."
            />
            <CodeBlock code={`from sklearn.preprocessing import StandardScaler

# Create interaction features
df['Rooms_per_Household'] = df['AveRooms'] / df['AveOccup']
df['Bedrooms_per_Room'] = df['AveBedrms'] / df['AveRooms']

# Scaling numerical features
scaler = StandardScaler()
features = df.drop('MedHouseVal', axis=1)
scaled_features = scaler.fit_transform(features)

X = scaled_features
y = df['MedHouseVal']`} />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border border-zinc-800 rounded-xl bg-zinc-900/30">
                <h4 className="text-zinc-100 font-medium mb-2">Why Scale?</h4>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Algorithms like Linear Regression are sensitive to the scale of input features. Standardizing ensures all features contribute equally to the distance calculations.
                </p>
              </div>
              <div className="p-4 border border-zinc-800 rounded-xl bg-zinc-900/30">
                <h4 className="text-zinc-100 font-medium mb-2">Interaction Features</h4>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Combining features like Rooms and Occupancy can reveal hidden patterns (e.g., crowding) that are more predictive than raw counts.
                </p>
              </div>
            </div>
          </motion.div>
        );

      case 5:
        return (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <SectionTitle 
              icon={Cpu} 
              title="Model Development" 
              subtitle="Training multiple regressors for comparison."
            />
            <CodeBlock code={`from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 1. Linear Regression
lr = LinearRegression()
lr.fit(X_train, y_train)

# 2. Random Forest
rf = RandomForestRegressor(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)

# 3. XGBoost
xgb_model = xgb.XGBRegressor(objective='reg:squarederror', n_estimators=100)
xgb_model.fit(X_train, y_train)`} />
          </motion.div>
        );

      case 6:
        return (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
            <SectionTitle 
              icon={CheckCircle2} 
              title="Model Evaluation" 
              subtitle="Comparing RMSE and R² scores."
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl">
                <h3 className="text-sm font-medium text-zinc-400 mb-6 uppercase tracking-widest">RMSE (Lower is Better)</h3>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={MODEL_PERFORMANCE}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                      <XAxis dataKey="name" stroke="#52525b" fontSize={10} />
                      <YAxis stroke="#52525b" fontSize={12} />
                      <Tooltip contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46' }} />
                      <Bar dataKey="RMSE" fill="#f97316" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl">
                <h3 className="text-sm font-medium text-zinc-400 mb-6 uppercase tracking-widest">R² Score (Higher is Better)</h3>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={MODEL_PERFORMANCE}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                      <XAxis dataKey="name" stroke="#52525b" fontSize={10} />
                      <YAxis stroke="#52525b" fontSize={12} domain={[0, 1]} />
                      <Tooltip contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46' }} />
                      <Bar dataKey="R2" fill="#22c55e" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </motion.div>
        );

      case 7:
        return (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
            <SectionTitle 
              icon={Eye} 
              title="Visualization" 
              subtitle="Analyzing model predictions and feature importance."
            />
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl">
                <h3 className="text-sm font-medium text-zinc-400 mb-6 uppercase tracking-widest">Actual vs Predicted</h3>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                      <XAxis type="number" dataKey="actual" name="Actual" unit="$" stroke="#52525b" />
                      <YAxis type="number" dataKey="predicted" name="Predicted" unit="$" stroke="#52525b" />
                      <ZAxis type="number" range={[50, 50]} />
                      <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                      <Scatter name="Predictions" data={ACTUAL_VS_PRED} fill="#f97316" fillOpacity={0.6} />
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl">
                <h3 className="text-sm font-medium text-zinc-400 mb-6 uppercase tracking-widest">Feature Importance (XGBoost)</h3>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={FEATURE_IMPORTANCE} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" horizontal={false} />
                      <XAxis type="number" stroke="#52525b" fontSize={12} />
                      <YAxis dataKey="feature" type="category" stroke="#52525b" fontSize={10} width={80} />
                      <Tooltip contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46' }} />
                      <Bar dataKey="importance" fill="#f97316" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </motion.div>
        );

      case 8:
        return (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <SectionTitle 
              icon={Calculator} 
              title="Live Prediction" 
              subtitle="Test the model with custom inputs."
            />
            <PredictionForm />
          </motion.div>
        );

      case 9:
        return (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <SectionTitle 
              icon={FileText} 
              title="Final Output & Insights" 
              subtitle="Summary of project findings."
            />
            <div className="bg-zinc-900/50 border border-zinc-800 p-8 rounded-2xl space-y-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Best Model: XGBoost Regressor</h3>
                  <p className="text-zinc-400 text-sm">Achieved R² of 0.83 and RMSE of 0.47</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="text-orange-500 font-semibold uppercase text-xs tracking-widest">Key Insights</h4>
                  <ul className="space-y-3">
                    {[
                      'Median Income is the strongest predictor of house value.',
                      'Ensemble methods (RF, XGB) significantly outperform linear models.',
                      'Location (Lat/Long) plays a crucial role in capturing regional price trends.',
                      'House age has a positive but relatively small impact on price.'
                    ].map((text, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm text-zinc-300">
                        <ChevronRight className="w-4 h-4 text-orange-500 mt-0.5 shrink-0" />
                        {text}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="space-y-4">
                  <h4 className="text-orange-500 font-semibold uppercase text-xs tracking-widest">Future Improvements</h4>
                  <ul className="space-y-3">
                    {[
                      'Incorporate external data (interest rates, school ratings).',
                      'Hyperparameter tuning using GridSearchCV or Optuna.',
                      'Deploy as a real-time API using Flask or FastAPI.',
                      'Explore deep learning models (MLP) for potential gains.'
                    ].map((text, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm text-zinc-300">
                        <div className="w-1.5 h-1.5 rounded-full bg-zinc-700 mt-1.5 shrink-0" />
                        {text}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-orange-500/30">
      {/* Sidebar Navigation */}
      <aside className="fixed left-0 top-0 bottom-0 w-72 bg-zinc-900/50 border-r border-zinc-800 overflow-y-auto hidden xl:block">
        <div className="p-8">
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20">
              <Home className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-none">HousePrice</h1>
              <p className="text-[10px] text-zinc-500 uppercase tracking-widest mt-1">ML Predictor Pro</p>
            </div>
          </div>

          <nav className="space-y-1">
            {steps.map((step) => (
              <button
                key={step.id}
                onClick={() => setActiveStep(step.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 group",
                  activeStep === step.id 
                    ? "bg-orange-500 text-white shadow-lg shadow-orange-500/20" 
                    : "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
                )}
              >
                <step.icon className={cn("w-4 h-4", activeStep === step.id ? "text-white" : "text-zinc-500 group-hover:text-zinc-300")} />
                {step.label}
                {activeStep === step.id && (
                  <motion.div layoutId="active-pill" className="ml-auto w-1.5 h-1.5 rounded-full bg-white" />
                )}
              </button>
            ))}
          </nav>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-8 border-t border-zinc-800 bg-zinc-900/80 backdrop-blur">
          <div className="flex items-center gap-3 text-zinc-500 text-xs">
            <Code2 className="w-4 h-4" />
            <span>Python / Scikit-Learn</span>
          </div>
        </div>
      </aside>

      {/* Mobile Nav */}
      <div className="xl:hidden fixed top-0 left-0 right-0 h-16 bg-zinc-900/80 backdrop-blur border-b border-zinc-800 z-50 flex items-center px-6">
        <div className="flex items-center gap-3">
          <Home className="w-5 h-5 text-orange-500" />
          <span className="font-bold">HousePrice ML</span>
        </div>
        <select 
          value={activeStep} 
          onChange={(e) => setActiveStep(Number(e.target.value))}
          className="ml-auto bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-1.5 text-xs text-zinc-200"
        >
          {steps.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
        </select>
      </div>

      {/* Main Content */}
      <main className="xl:pl-72 pt-16 xl:pt-0">
        <div className="max-w-5xl mx-auto p-6 md:p-12">
          <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-500 text-[10px] font-bold uppercase tracking-widest mb-4">
                <Activity className="w-3 h-3" />
                Data Science Project
              </div>
              <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
                House Price Prediction <br />
                <span className="text-zinc-500">using Machine Learning</span>
              </h1>
            </div>
            <div className="flex items-center gap-4 text-zinc-500 text-sm font-mono">
              <div className="flex flex-col items-end">
                <span className="text-zinc-400">California Dataset</span>
                <span>20,640 Samples</span>
              </div>
              <div className="w-px h-10 bg-zinc-800" />
              <div className="flex flex-col items-end">
                <span className="text-zinc-400">Accuracy</span>
                <span className="text-green-500">83% R²</span>
              </div>
            </div>
          </header>

          <div className="min-h-[600px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
              >
                {renderStepContent()}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Footer Navigation */}
          <footer className="mt-20 pt-8 border-t border-zinc-800 flex items-center justify-between">
            <button 
              onClick={() => setActiveStep(Math.max(0, activeStep - 1))}
              disabled={activeStep === 0}
              className="px-6 py-2 rounded-xl border border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-900 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              Previous
            </button>
            <div className="flex gap-1">
              {steps.map(s => (
                <div key={s.id} className={cn("w-1.5 h-1.5 rounded-full transition-all", activeStep === s.id ? "bg-orange-500 w-4" : "bg-zinc-800")} />
              ))}
            </div>
            <button 
              onClick={() => setActiveStep(Math.min(steps.length - 1, activeStep + 1))}
              disabled={activeStep === steps.length - 1}
              className="px-6 py-2 rounded-xl bg-zinc-100 text-zinc-950 font-bold hover:bg-white disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              Next
            </button>
          </footer>
        </div>
      </main>
    </div>
  );
}

function PredictionForm() {
  const [inputs, setInputs] = useState({
    MedInc: 5.0,
    HouseAge: 25,
    AveRooms: 6.0,
    AveOccup: 3.0,
    Latitude: 34.0,
    Longitude: -118.0
  });
  const [prediction, setPrediction] = useState<number | null>(null);

  const handlePredict = () => {
    // Simple mock linear model for demonstration
    // Price = 0.4 * MedInc + 0.01 * HouseAge + 0.05 * AveRooms - 0.1 * AveOccup + Constant
    const base = 0.5;
    const pred = base + (inputs.MedInc * 0.45) + (inputs.HouseAge * 0.005) + (inputs.AveRooms * 0.02) - (inputs.AveOccup * 0.05);
    setPrediction(Math.max(0.5, pred));
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-zinc-900/50 border border-zinc-800 p-8 rounded-2xl">
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-zinc-400 uppercase tracking-widest mb-4">Input Features</h3>
        <div className="grid grid-cols-2 gap-4">
          {[
            { key: 'MedInc', label: 'Med. Income', min: 0.5, max: 15, step: 0.1, unit: '$10k' },
            { key: 'HouseAge', label: 'House Age', min: 1, max: 52, step: 1, unit: 'yrs' },
            { key: 'AveRooms', label: 'Avg Rooms', min: 1, max: 10, step: 0.1, unit: '' },
            { key: 'AveOccup', label: 'Avg Occup.', min: 1, max: 6, step: 0.1, unit: '' },
            { key: 'Latitude', label: 'Latitude', min: 32, max: 42, step: 0.01, unit: '°' },
            { key: 'Longitude', label: 'Longitude', min: -124, max: -114, step: 0.01, unit: '°' },
          ].map((field) => (
            <div key={field.key} className="space-y-1.5">
              <label className="text-[10px] text-zinc-500 uppercase font-bold">{field.label}</label>
              <div className="relative">
                <input 
                  type="number" 
                  value={inputs[field.key as keyof typeof inputs]}
                  onChange={(e) => setInputs({ ...inputs, [field.key]: parseFloat(e.target.value) })}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500 transition-colors"
                />
                <span className="absolute right-3 top-2 text-[10px] text-zinc-600">{field.unit}</span>
              </div>
            </div>
          ))}
        </div>
        <button 
          onClick={handlePredict}
          className="w-full mt-6 bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-orange-500/20 flex items-center justify-center gap-2"
        >
          <Calculator className="w-4 h-4" />
          Calculate Prediction
        </button>
      </div>

      <div className="flex flex-col items-center justify-center border-l border-zinc-800 pl-8">
        <div className="text-center space-y-2">
          <p className="text-xs text-zinc-500 uppercase tracking-widest font-bold">Predicted Median Value</p>
          {prediction !== null ? (
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }}
              className="space-y-2"
            >
              <div className="text-6xl font-black text-white tracking-tighter">
                ${(prediction * 100000).toLocaleString()}
              </div>
              <p className="text-orange-500 font-mono text-sm">Model Confidence: 83%</p>
            </motion.div>
          ) : (
            <div className="text-zinc-700 py-12">
              <TrendingUp className="w-16 h-16 mx-auto mb-4 opacity-20" />
              <p className="text-sm italic">Enter values and click predict</p>
            </div>
          )}
        </div>
        
        <div className="mt-12 w-full p-4 bg-zinc-950/50 rounded-xl border border-zinc-800">
          <div className="flex items-center gap-2 mb-3">
            <MapPin className="w-4 h-4 text-orange-500" />
            <span className="text-xs font-bold text-zinc-300">Location Context</span>
          </div>
          <div className="h-32 bg-zinc-900 rounded-lg relative overflow-hidden">
            {/* Mock Map visualization */}
            <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#3f3f46_1px,transparent_1px)] [background-size:16px_16px]" />
            <motion.div 
              animate={{ x: (inputs.Longitude + 119) * 20, y: (37 - inputs.Latitude) * 20 }}
              className="absolute w-4 h-4 bg-orange-500 rounded-full border-2 border-white shadow-lg shadow-orange-500/50"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

