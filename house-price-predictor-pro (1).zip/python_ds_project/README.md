# House Price Prediction Project

This project provides an end-to-end solution for predicting house prices using Machine Learning.

## Project Structure

- `train_model.py`: Python script to load data, perform EDA, train multiple models (Linear Regression, Random Forest, XGBoost), and save the best model.
- `app.py`: Flask web application to serve predictions via a REST API.
- `model.pkl`: The serialized trained model (generated after running `train_model.py`).
- `requirements.txt`: List of Python dependencies.

## How to Run (Python)

1. **Install Dependencies**:
   ```bash
   pip install pandas numpy matplotlib seaborn scikit-learn xgboost flask
   ```

2. **Train the Model**:
   ```bash
   python train_model.py
   ```
   This will output model performance metrics and save `model.pkl`.

3. **Start the Web App**:
   ```bash
   python app.py
   ```
   The Flask server will start on `http://localhost:5000`.

## Web Interface (React/TypeScript)

The primary web interface for this project is built using React and TypeScript for a modern, interactive experience. It includes:
- **Interactive EDA Dashboard**: Visualizing price trends and city distributions.
- **Real-time Prediction Form**: Instant valuation based on property features.

The React app is pre-configured to run in this environment.
