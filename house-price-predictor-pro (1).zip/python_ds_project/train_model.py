import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, r2_score
import pickle
import os

# 1. Load Dataset (Simulated California Housing)
def load_data():
    # In a real scenario, use: from sklearn.datasets import fetch_california_housing
    # data = fetch_california_housing()
    # df = pd.DataFrame(data.data, columns=data.feature_names)
    # df['Price'] = data.target
    
    # For demonstration, we'll create a synthetic dataset matching the web app's features
    np.random.seed(42)
    n = 1000
    data = {
        'posted_by': np.random.choice(['Owner', 'Dealer', 'Builder'], n),
        'rera': np.random.choice([0, 1], n),
        'rooms': np.random.randint(1, 6, n),
        'sqft': np.random.randint(500, 5000, n),
        'ready_to_move': np.random.choice([0, 1], n),
        'resale': np.random.choice([0, 1], n),
        'city': np.random.choice(['Mumbai', 'Delhi', 'Bangalore', 'Pune', 'Hyderabad'], n),
    }
    df = pd.DataFrame(data)
    
    # Target variable with some noise
    df['price'] = (df['rooms'] * 1500000 + 
                  df['sqft'] * 3500 + 
                  df['rera'] * 500000 + 
                  np.random.normal(0, 200000, n))
    return df

# 2. Preprocessing
def preprocess(df):
    # Handle missing values
    df = df.fillna(df.median(numeric_only=True))
    
    # Encode categorical variables
    df = pd.get_dummies(df, columns=['posted_by', 'city'], drop_first=True)
    
    # Feature Engineering
    df['price_per_sqft'] = df['price'] / df['sqft']
    
    return df

# 3. Training
def train():
    print("Loading and preprocessing data...")
    df = load_data()
    df = preprocess(df)
    
    X = df.drop(['price', 'price_per_sqft'], axis=1)
    y = df['price']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42),
        "XGBoost": XGBRegressor(n_estimators=100, learning_rate=0.1, random_state=42)
    }
    
    best_model = None
    best_r2 = -float('inf')
    
    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        r2 = r2_score(y_test, y_pred)
        print(f"{name} -> RMSE: {rmse:.2f}, R2: {r2:.4f}")
        
        if r2 > best_r2:
            best_r2 = r2
            best_model = model
            
    # Save the best model
    with open('model.pkl', 'wb') as f:
        pickle.dump(best_model, f)
    print(f"Best model saved to model.pkl with R2: {best_r2:.4f}")

if __name__ == "__main__":
    train()
