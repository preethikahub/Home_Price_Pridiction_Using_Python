from flask import Flask, render_react, request, jsonify
import pickle
import numpy as np
import pandas as pd

app = Flask(__name__)

# Load the trained model
try:
    with open('model.pkl', 'rb') as f:
        model = pickle.load(f)
except FileNotFoundError:
    model = None

@app.route('/')
def home():
    return "Flask Server for House Price Prediction. Use /predict for POST requests."

@app.route('/predict', methods=['POST'])
def predict():
    if not model:
        return jsonify({"error": "Model not found. Please run train_model.py first."}), 500
    
    data = request.get_json()
    
    # Map input data to model features (this must match the training preprocessing)
    # For simplicity, we'll assume the client sends the correct feature vector
    # In a real app, you'd use a pipeline or a preprocessor object
    
    try:
        features = np.array(data['features']).reshape(1, -1)
        prediction = model.predict(features)
        return jsonify({"predicted_price": float(prediction[0])})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == "__main__":
    app.run(port=5000, debug=True)
