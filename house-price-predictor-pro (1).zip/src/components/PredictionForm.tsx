import React, { useState } from 'react';
import { predictPrice, HouseData } from '../lib/ml-model';
import { Home, Ruler, Building2, CheckCircle2, MapPin, Calculator } from 'lucide-react';
import { motion } from 'motion/react';

export default function PredictionForm() {
  const [formData, setFormData] = useState<Omit<HouseData, 'price'>>({
    ownerType: 'Owner',
    reraApproved: true,
    rooms: 3,
    squareFeet: 1500,
    readyToMove: true,
    resale: false,
    city: 'Mumbai'
  });

  const [prediction, setPrediction] = useState<number | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsCalculating(true);
    setTimeout(() => {
      const price = predictPrice(formData);
      setPrediction(price);
      setIsCalculating(false);
    }, 800);
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-100">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-indigo-600 rounded-lg text-white">
          <Calculator size={24} />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Price Estimator</h2>
          <p className="text-slate-500 text-sm">Enter property details for a real-time valuation</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Owner Type */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Building2 size={16} /> Posted By
            </label>
            <select
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all bg-slate-50"
              value={formData.ownerType}
              onChange={(e) => setFormData({ ...formData, ownerType: e.target.value as any })}
            >
              <option value="Owner">Owner</option>
              <option value="Dealer">Dealer</option>
              <option value="Builder">Builder</option>
            </select>
          </div>

          {/* City */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <MapPin size={16} /> City
            </label>
            <select
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all bg-slate-50"
              value={formData.city}
              onChange={(e) => setFormData({ ...formData, city: e.target.value })}
            >
              <option value="Mumbai">Mumbai</option>
              <option value="Delhi">Delhi</option>
              <option value="Bangalore">Bangalore</option>
              <option value="Pune">Pune</option>
              <option value="Hyderabad">Hyderabad</option>
            </select>
          </div>

          {/* Rooms */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Home size={16} /> Number of Rooms
            </label>
            <input
              type="number"
              min="1"
              max="10"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all bg-slate-50"
              value={formData.rooms}
              onChange={(e) => setFormData({ ...formData, rooms: parseInt(e.target.value) })}
            />
          </div>

          {/* Square Feet */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Ruler size={16} /> Square Feet
            </label>
            <input
              type="number"
              min="100"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all bg-slate-50"
              value={formData.squareFeet}
              onChange={(e) => setFormData({ ...formData, squareFeet: parseInt(e.target.value) })}
            />
          </div>
        </div>

        {/* Checkboxes */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-4">
          <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-100 bg-slate-50 cursor-pointer hover:bg-slate-100 transition-colors">
            <input
              type="checkbox"
              className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500"
              checked={formData.reraApproved}
              onChange={(e) => setFormData({ ...formData, reraApproved: e.target.checked })}
            />
            <span className="text-sm font-medium text-slate-700">RERA Approved</span>
          </label>
          <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-100 bg-slate-50 cursor-pointer hover:bg-slate-100 transition-colors">
            <input
              type="checkbox"
              className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500"
              checked={formData.readyToMove}
              onChange={(e) => setFormData({ ...formData, readyToMove: e.target.checked })}
            />
            <span className="text-sm font-medium text-slate-700">Ready to Move</span>
          </label>
          <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-100 bg-slate-50 cursor-pointer hover:bg-slate-100 transition-colors">
            <input
              type="checkbox"
              className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500"
              checked={formData.resale}
              onChange={(e) => setFormData({ ...formData, resale: e.target.checked })}
            />
            <span className="text-sm font-medium text-slate-700">Resale Property</span>
          </label>
        </div>

        <button
          type="submit"
          disabled={isCalculating}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-6 rounded-xl shadow-lg shadow-indigo-200 transition-all transform active:scale-[0.98] disabled:opacity-70 flex items-center justify-center gap-2"
        >
          {isCalculating ? (
            <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>Predict House Price</>
          )}
        </button>
      </form>

      {prediction !== null && !isCalculating && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-8 p-6 bg-indigo-50 rounded-2xl border border-indigo-100 text-center"
        >
          <p className="text-indigo-600 font-semibold text-sm uppercase tracking-wider mb-1">Estimated Market Value</p>
          <h3 className="text-4xl font-black text-indigo-900">
            ₹{prediction.toLocaleString('en-IN')}
          </h3>
          <p className="text-indigo-400 text-xs mt-2 flex items-center justify-center gap-1">
            <CheckCircle2 size={12} /> Prediction based on current market trends
          </p>
        </motion.div>
      )}
    </div>
  );
}
