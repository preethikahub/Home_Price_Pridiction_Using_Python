import { motion } from 'motion/react';
import PredictionForm from './components/PredictionForm';
import Dashboard from './components/Dashboard';
import { LayoutDashboard, LineChart, Database, Github, BookOpen } from 'lucide-react';
import { useState } from 'react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'predict' | 'eda'>('predict');

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">H</div>
              <span className="text-xl font-black tracking-tight text-slate-900 hidden sm:block">
                Prophet<span className="text-indigo-600">AI</span>
              </span>
            </div>
            <div className="flex gap-1 bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => setActiveTab('predict')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                  activeTab === 'predict' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <LayoutDashboard size={16} /> Predict
              </button>
              <button
                onClick={() => setActiveTab('eda')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                  activeTab === 'eda' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <LineChart size={16} /> Analysis
              </button>
            </div>
            <div className="flex items-center gap-4">
              <a href="#" className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
                <Github size={20} />
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="bg-white border-b border-slate-100 pt-12 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span className="inline-block px-4 py-1.5 mb-4 text-xs font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 rounded-full">
              Machine Learning Project
            </span>
            <h1 className="text-5xl md:text-6xl font-black text-slate-900 mb-6 tracking-tight">
              House Price <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">Prediction</span>
            </h1>
            <p className="max-w-2xl mx-auto text-lg text-slate-500 leading-relaxed">
              An end-to-end data science solution leveraging advanced regression models to estimate property values with high precision.
            </p>
          </motion.div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Main App */}
          <div className="lg:col-span-8">
            {activeTab === 'predict' ? <PredictionForm /> : <Dashboard />}
          </div>

          {/* Right Column: Project Info */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2 uppercase tracking-wider">
                <Database size={16} className="text-indigo-600" /> Model Architecture
              </h3>
              <ul className="space-y-4">
                {[
                  { name: 'Linear Regression', score: '82%', desc: 'Baseline performance' },
                  { name: 'Random Forest', score: '91%', desc: 'Ensemble learning' },
                  { name: 'XGBoost', score: '94%', desc: 'Gradient boosting (Best)' },
                ].map((model, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-2 shrink-0" />
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-slate-800 text-sm">{model.name}</span>
                        <span className="text-xs font-black text-indigo-600">{model.score} R²</span>
                      </div>
                      <p className="text-xs text-slate-400">{model.desc}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-slate-900 p-6 rounded-2xl shadow-xl text-white">
              <h3 className="text-sm font-bold mb-4 flex items-center gap-2 uppercase tracking-wider">
                <BookOpen size={16} className="text-indigo-400" /> Project Assets
              </h3>
              <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                The full Python Data Science pipeline is available in the project source code, including EDA, Feature Engineering, and Model Training scripts.
              </p>
              <div className="space-y-2">
                {['train_model.py', 'eda_notebook.ipynb', 'model.pkl', 'requirements.txt'].map((file, i) => (
                  <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors cursor-pointer">
                    <span className="text-xs font-mono text-slate-300">{file}</span>
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-slate-900 rounded flex items-center justify-center text-white text-[10px] font-bold">H</div>
            <span className="font-bold text-slate-900">ProphetAI</span>
          </div>
          <p className="text-sm text-slate-400">© 2026 End-to-End Data Science Project. Built with React & TypeScript.</p>
          <div className="flex gap-6">
            <a href="#" className="text-sm text-slate-500 hover:text-indigo-600 transition-colors font-medium">Documentation</a>
            <a href="#" className="text-sm text-slate-500 hover:text-indigo-600 transition-colors font-medium">Dataset</a>
            <a href="#" className="text-sm text-slate-500 hover:text-indigo-600 transition-colors font-medium">License</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
