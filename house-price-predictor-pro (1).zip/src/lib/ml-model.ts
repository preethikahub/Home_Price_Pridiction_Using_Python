import * as ss from 'simple-statistics';

export interface HouseData {
  ownerType: 'Owner' | 'Dealer' | 'Builder';
  reraApproved: boolean;
  rooms: number;
  squareFeet: number;
  readyToMove: boolean;
  resale: boolean;
  city: string;
  price: number;
}

// Sample data inspired by housing datasets
export const sampleData: HouseData[] = [
  { ownerType: 'Owner', reraApproved: true, rooms: 3, squareFeet: 1500, readyToMove: true, resale: false, city: 'Mumbai', price: 8500000 },
  { ownerType: 'Dealer', reraApproved: false, rooms: 2, squareFeet: 1000, readyToMove: true, resale: true, city: 'Delhi', price: 4500000 },
  { ownerType: 'Builder', reraApproved: true, rooms: 4, squareFeet: 2500, readyToMove: false, resale: false, city: 'Bangalore', price: 12000000 },
  { ownerType: 'Owner', reraApproved: true, rooms: 3, squareFeet: 1800, readyToMove: true, resale: true, city: 'Mumbai', price: 9500000 },
  { ownerType: 'Dealer', reraApproved: true, rooms: 2, squareFeet: 1200, readyToMove: true, resale: false, city: 'Pune', price: 5500000 },
  { ownerType: 'Builder', reraApproved: false, rooms: 5, squareFeet: 3500, readyToMove: false, resale: false, city: 'Hyderabad', price: 18000000 },
  { ownerType: 'Owner', reraApproved: true, rooms: 1, squareFeet: 600, readyToMove: true, resale: true, city: 'Delhi', price: 2500000 },
  { ownerType: 'Dealer', reraApproved: true, rooms: 3, squareFeet: 1600, readyToMove: true, resale: false, city: 'Bangalore', price: 7800000 },
  { ownerType: 'Builder', reraApproved: true, rooms: 2, squareFeet: 1100, readyToMove: true, resale: false, city: 'Mumbai', price: 6200000 },
  { ownerType: 'Owner', reraApproved: false, rooms: 4, squareFeet: 2200, readyToMove: true, resale: true, city: 'Pune', price: 11000000 },
  { ownerType: 'Dealer', reraApproved: true, rooms: 3, squareFeet: 1400, readyToMove: true, resale: false, city: 'Hyderabad', price: 7200000 },
  { ownerType: 'Builder', reraApproved: true, rooms: 3, squareFeet: 1700, readyToMove: false, resale: false, city: 'Delhi', price: 8900000 },
];

export function predictPrice(input: Omit<HouseData, 'price'>): number {
  // Simple heuristic-based linear model for demonstration
  // In a real app, this would be a trained model's coefficients
  
  let basePrice = 2000000; // Base price for a minimal unit
  
  // Feature weights
  const roomWeight = 1500000;
  const sqftWeight = 3500;
  const cityMultipliers: Record<string, number> = {
    'Mumbai': 1.5,
    'Delhi': 1.2,
    'Bangalore': 1.3,
    'Pune': 1.1,
    'Hyderabad': 1.15,
  };
  
  const ownerMultipliers: Record<string, number> = {
    'Owner': 1.0,
    'Dealer': 0.95,
    'Builder': 1.1,
  };

  let prediction = basePrice;
  prediction += input.rooms * roomWeight;
  prediction += input.squareFeet * sqftWeight;
  
  if (input.reraApproved) prediction *= 1.05;
  if (input.readyToMove) prediction *= 1.1;
  if (input.resale) prediction *= 0.9;
  
  const cityMult = cityMultipliers[input.city] || 1.0;
  const ownerMult = ownerMultipliers[input.ownerType] || 1.0;
  
  prediction *= cityMult;
  prediction *= ownerMult;
  
  return Math.round(prediction);
}

export function getCorrelationData() {
  // Simple correlation between SqFt and Price for visualization
  return sampleData.map(d => ({
    x: d.squareFeet,
    y: d.price,
    rooms: d.rooms
  }));
}
