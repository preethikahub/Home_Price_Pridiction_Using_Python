/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  ScatterChart, Scatter, ZAxis, BarChart, Bar, Cell,
  AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts';
import { 
  Home, Database, Search, Eraser, Cpu, BarChart3, CheckCircle2, 
  Play, Code2, ChevronRight, Info, MapPin, BedDouble, Square, 
  Layers, TrendingUp, AlertCircle, Github, ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { cn } from '@/src/lib/utils';

// --- Mock Data & Constants ---

const CALIFORNIA_STATS = [
  { name: 'MedInc', label: 'Median Income', min: 0.5, max: 15.0, avg: 3.87 },
  { name: 'HouseAge', label: 'House Age', min: 1, max: 52, avg: 28.6 },
  { name: 'AveRooms', label: 'Avg Rooms', min: 1, max: 10, avg: 5.42 },
  { name: 'AveBedrms', label: 'Avg Bedrooms', min: 0.8, max: 5, avg: 1.09 },
  { name: 'Population', label: 'Population', min: 3, max: 35000, avg: 1425 },
  { name: 'AveOccup', label: 'Avg Occupancy', min: 1, max: 10, avg: 3.07 },
  { name: 'Latitude', label: 'Latitude', min: 32, max: 42, avg: 35.6 },
  { name: 'Longitude', label: 'Longitude', min: -124, max: -114, avg: -119.5 },
];

const CORRELATION_DATA = [
  { x: 'MedInc', y: 'Price', value: 0.68 },
  { x: 'HouseAge', y: 'Price', value: 0.11 },
  { x: 'AveRooms', y: 'Price', value: 0.15 },
  { x: 'AveBedrms', y: 'Price', value: -0.05 },
  { x: 'Population', y: 'Price', value: -0.02 },
  { x: 'AveOccup', y: 'Price', value: -0.02 },
  { x: 'Latitude', y: 'Price', value: -0.14 },
  { x: 'Longitude', y: 'Price', value: -0.05 },
];

const MODEL_PERFORMANCE = [
  { name: 'Linear Regression', rmse: 0.72, r2: 0.61, color: '#94a3b8' },
  { name: 'Random Forest', rmse: 0.51, r2: 0.80, color: '#6366f1' },
  { name: 'XGBoost', rmse: 0.47, r2: 0.83, color: '#f43f5e' },
];

const FEATURE_IMPORTANCE = [
  { name: 'MedInc', importance: 0.52 },
  { name: 'AveOccup', importance: 0.14 },
  { name: 'Latitude', importance: 0.09 },
  { name: 'Longitude', importance: 0.09 },
  { name: 'HouseAge', importance: 0.05 },
  { name: 'AveRooms', importance: 0.04 },
  { name: 'Population', importance: 0.03 },
  { name: 'AveBedrms', importance: 0.04 },
];

// --- Components ---

const CodeBlock = ({ code, language = 'python' }: { code: string; language?: string }) => (
  <div className="relative group rounded-xl overflow-hidden bg-slate-950 border border-slate-800 my-4">
    <div className="flex items-center justify-between px-4 py-2 bg-slate-900/50 border-bottom border-slate-800">
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/40" />
        <div className="w-3 h-3 rounded-full bg-amber-500/20 border border-amber-500/40" />
        <div className="w-3 h-3 rounded-full bg-emerald-500/20 border border-emerald-500/40" />
      </div>
      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">{language}</span>
    </div>
    <pre className="p-4 text-sm font-mono text-slate-300 overflow-x-auto leading-relaxed">
      <code>{code}</code>
    </pre>
  </div>
);

const SectionHeader = ({ icon: Icon, title, subtitle }: { icon: any; title: string; subtitle: string }) => (
  <div className="mb-8">
    <div className="flex items-center gap-3 mb-2">
      <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
        <Icon size={24} />
      </div>
      <h2 className="text-2xl font-bold text-slate-100 tracking-tight">{title}</h2>
    </div>
    <p className="text-slate-400 max-w-2xl leading-relaxed">{subtitle}</p>
  </div>
);

// --- Main App ---

export default function App() {
  const [activeSection, setActiveSection] = useState('intro');
  const [predictionInputs, setPredictionInputs] = useState({
    MedInc: 3.8,
    HouseAge: 28,
    AveRooms: 5.4,
    AveOccup: 3.0,
  });

  const predictedPrice = useMemo(() => {
    // Simplified linear approximation for demo
    const base = 0.5;
    const incomeEffect = predictionInputs.MedInc * 0.4;
    const ageEffect = predictionInputs.HouseAge * 0.005;
    const roomEffect = predictionInputs.AveRooms * 0.02;
    const occupEffect = predictionInputs.AveOccup * -0.01;
    return (base + incomeEffect + ageEffect + roomEffect + occupEffect).toFixed(2);
  }, [predictionInputs]);

  const sections = [
    { id: 'intro', label: 'Introduction', icon: Home },
    { id: 'dataset', label: 'Dataset Loading', icon: Database },
    { id: 'eda', label: 'Data Exploration', icon: Search },
    { id: 'cleaning', label: 'Data Cleaning', icon: Eraser },
    { id: 'feature', label: 'Feature Engineering', icon: Layers },
    { id: 'modeling', label: 'Model Development', icon: Cpu },
    { id: 'evaluation', label: 'Model Evaluation', icon: BarChart3 },
    { id: 'prediction', label: 'Live Prediction', icon: Play },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-500/30">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 bottom-0 w-64 bg-slate-900/50 border-r border-slate-800/50 backdrop-blur-xl z-50 hidden lg:flex flex-col">
        <div className="p-6 border-b border-slate-800/50">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <TrendingUp size={18} className="text-white" />
            </div>
            <h1 className="font-bold text-lg tracking-tight text-white">PricePredict</h1>
          </div>
          <p className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Data Science Portfolio</p>
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          {sections.map((s) => (
            <button
              key={s.id}
              onClick={() => setActiveSection(s.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
                activeSection === s.id 
                  ? "bg-indigo-500/10 text-indigo-400 shadow-sm" 
                  : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
              )}
            >
              <s.icon size={18} className={cn(activeSection === s.id ? "text-indigo-400" : "text-slate-500 group-hover:text-slate-300")} />
              <span className="text-sm font-medium">{s.label}</span>
              {activeSection === s.id && (
                <motion.div layoutId="active-nav" className="ml-auto w-1.5 h-1.5 rounded-full bg-indigo-400" />
              )}
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-slate-800/50">
          <div className="flex items-center gap-3 text-slate-400 hover:text-slate-200 cursor-pointer transition-colors">
            <Github size={18} />
            <span className="text-xs font-medium">View Source</span>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-64 p-6 lg:p-12 max-w-6xl mx-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            {activeSection === 'intro' && (
              <section id="intro">
                <div className="relative mb-12 rounded-3xl overflow-hidden bg-slate-900 border border-slate-800 p-8 lg:p-16">
                  <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-indigo-500/10 to-transparent pointer-events-none" />
                  <div className="relative z-10">
                    <span className="inline-block px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-[10px] font-bold uppercase tracking-widest mb-6">
                      Project Showcase
                    </span>
                    <h1 className="text-4xl lg:text-6xl font-black text-white mb-6 leading-tight tracking-tight">
                      House Price Prediction <br />
                      <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
                        using Machine Learning
                      </span>
                    </h1>
                    <p className="text-lg text-slate-400 max-w-2xl mb-8 leading-relaxed">
                      Predicting real estate value is a fundamental regression task. This project explores the California Housing dataset, 
                      applying advanced feature engineering and comparing state-of-the-art models like XGBoost and Random Forest.
                    </p>
                    <div className="flex flex-wrap gap-4">
                      <button onClick={() => setActiveSection('dataset')} className="px-6 py-3 rounded-xl bg-indigo-500 hover:bg-indigo-600 text-white font-bold transition-all flex items-center gap-2 shadow-lg shadow-indigo-500/20">
                        Explore Project <ChevronRight size={18} />
                      </button>
                      <div className="flex items-center gap-4 px-6 py-3 rounded-xl bg-slate-800/50 border border-slate-700">
                        <div className="flex -space-x-2">
                          {[1,2,3].map(i => (
                            <div key={i} className="w-8 h-8 rounded-full border-2 border-slate-900 bg-slate-700 flex items-center justify-center text-[10px] font-bold">
                              {i === 1 ? 'PY' : i === 2 ? 'PD' : 'SK'}
                            </div>
                          ))}
                        </div>
                        <span className="text-xs font-medium text-slate-400">Python Stack</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    { title: 'Regression Task', desc: 'Predicting continuous values (Price) based on multiple independent features.', icon: TrendingUp },
                    { title: 'Feature Importance', desc: 'Identifying which factors like income or location drive property value most.', icon: BarChart3 },
                    { title: 'Model Optimization', desc: 'Tuning hyperparameters for Random Forest and Gradient Boosting models.', icon: Cpu },
                  ].map((card, i) => (
                    <div key={i} className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-indigo-500/50 transition-colors">
                      <card.icon className="text-indigo-400 mb-4" size={24} />
                      <h3 className="font-bold text-white mb-2">{card.title}</h3>
                      <p className="text-sm text-slate-400 leading-relaxed">{card.desc}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {activeSection === 'dataset' && (
              <section id="dataset">
                <SectionHeader 
                  icon={Database} 
                  title="Dataset Loading" 
                  subtitle="We use the California Housing dataset, which contains 20,640 observations of housing blocks in California from the 1990 census."
                />
                
                <CodeBlock code={`import pandas as pd
import numpy as np
from sklearn.datasets import fetch_california_housing

# Load the dataset
housing = fetch_california_housing()
df = pd.DataFrame(housing.data, columns=housing.feature_names)
df['Price'] = housing.target

# Display basic info
print(f"Dataset Shape: {df.shape}")
print(df.head())
print(df.describe())`} />

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
                  <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Feature Summary</h3>
                    <div className="space-y-4">
                      {CALIFORNIA_STATS.slice(0, 4).map((stat) => (
                        <div key={stat.name} className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-bold text-white">{stat.label}</p>
                            <p className="text-[10px] text-slate-500 font-mono">{stat.name}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-mono text-indigo-400">{stat.avg}</p>
                            <p className="text-[10px] text-slate-500">Avg Value</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Target Distribution</h3>
                    <div className="h-[200px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={[
                          { x: 0, y: 10 }, { x: 1, y: 150 }, { x: 2, y: 300 }, 
                          { x: 3, y: 200 }, { x: 4, y: 100 }, { x: 5, y: 400 }
                        ]}>
                          <defs>
                            <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <Area type="monotone" dataKey="y" stroke="#6366f1" fillOpacity={1} fill="url(#colorPrice)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                    <p className="text-[10px] text-center text-slate-500 mt-4">Median House Value (in $100,000s)</p>
                  </div>
                </div>
              </section>
            )}

            {activeSection === 'eda' && (
              <section id="eda">
                <SectionHeader 
                  icon={Search} 
                  title="Exploratory Data Analysis" 
                  subtitle="Visualizing relationships between features and the target variable to identify patterns and correlations."
                />

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                  <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Correlation with Price</h3>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={CORRELATION_DATA} layout="vertical">
                          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
                          <XAxis type="number" domain={[-0.2, 0.8]} hide />
                          <YAxis dataKey="x" type="category" stroke="#64748b" fontSize={12} width={80} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px' }}
                            itemStyle={{ color: '#818cf8' }}
                          />
                          <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                            {CORRELATION_DATA.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.value > 0 ? '#6366f1' : '#f43f5e'} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Income vs. Price</h3>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <ScatterChart>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                          <XAxis type="number" dataKey="x" name="Income" unit="k" stroke="#64748b" />
                          <YAxis type="number" dataKey="y" name="Price" unit="k" stroke="#64748b" />
                          <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                          <Scatter name="Houses" data={[
                            { x: 2, y: 1.5 }, { x: 3, y: 2.1 }, { x: 4, y: 2.8 }, { x: 5, y: 3.5 },
                            { x: 6, y: 4.2 }, { x: 2.5, y: 1.8 }, { x: 3.8, y: 2.5 }, { x: 5.2, y: 4.8 }
                          ]} fill="#818cf8" />
                        </ScatterChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                <CodeBlock code={`import seaborn as sns
import matplotlib.pyplot as plt

# Correlation Heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Feature Correlation Heatmap')
plt.show()

# Distribution of Target
sns.histplot(df['Price'], kde=True, color='indigo')
plt.title('Distribution of House Prices')
plt.show()`} />
              </section>
            )}

            {activeSection === 'cleaning' && (
              <section id="cleaning">
                <SectionHeader 
                  icon={Eraser} 
                  title="Data Cleaning" 
                  subtitle="Handling missing values and outliers to ensure model robustness. In this dataset, we look for capped values and extreme outliers."
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800">
                    <div className="flex items-center gap-3 mb-4">
                      <CheckCircle2 className="text-emerald-400" size={20} />
                      <h4 className="font-bold text-white">Missing Values</h4>
                    </div>
                    <p className="text-sm text-slate-400 leading-relaxed">
                      The California dataset is remarkably clean with no missing values. However, in real-world scenarios, 
                      we would use <code className="text-indigo-400">SimpleImputer</code> or <code className="text-indigo-400">fillna()</code>.
                    </p>
                  </div>
                  <div className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800">
                    <div className="flex items-center gap-3 mb-4">
                      <AlertCircle className="text-amber-400" size={20} />
                      <h4 className="font-bold text-white">Outlier Detection</h4>
                    </div>
                    <p className="text-sm text-slate-400 leading-relaxed">
                      We identified that house prices are capped at 5.0 ($500k). Removing these capped values often improves 
                      model generalization for mid-range properties.
                    </p>
                  </div>
                </div>

                <CodeBlock code={`# Check for missing values
print(df.isnull().sum())

# Handling outliers (e.g., removing capped prices)
df = df[df['Price'] < 5.0]

# Detecting outliers using IQR
Q1 = df['AveRooms'].quantile(0.25)
Q3 = df['AveRooms'].quantile(0.75)
IQR = Q3 - Q1
df = df[~((df['AveRooms'] < (Q1 - 1.5 * IQR)) | (df['AveRooms'] > (Q3 + 1.5 * IQR)))]`} />
              </section>
            )}

            {activeSection === 'feature' && (
              <section id="feature">
                <SectionHeader 
                  icon={Layers} 
                  title="Feature Engineering" 
                  subtitle="Creating new features from existing ones to capture complex relationships, and scaling numerical data for better model performance."
                />

                <div className="bg-indigo-500/5 border border-indigo-500/20 rounded-2xl p-6 mb-8">
                  <h4 className="font-bold text-indigo-400 mb-4 flex items-center gap-2">
                    <Info size={18} /> Engineering Strategy
                  </h4>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3 text-sm text-slate-300">
                      <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
                      <span><strong>Rooms per Household:</strong> Normalizing total rooms by occupancy to get a better sense of space.</span>
                    </li>
                    <li className="flex items-start gap-3 text-sm text-slate-300">
                      <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
                      <span><strong>Bedrooms per Room:</strong> A ratio indicating the density of bedrooms relative to living space.</span>
                    </li>
                    <li className="flex items-start gap-3 text-sm text-slate-300">
                      <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
                      <span><strong>Standard Scaling:</strong> Using StandardScaler to ensure all features have zero mean and unit variance.</span>
                    </li>
                  </ul>
                </div>

                <CodeBlock code={`# Create interaction features
df['Rooms_per_Household'] = df['AveRooms'] / df['AveOccup']
df['Bedrooms_per_Room'] = df['AveBedrms'] / df['AveRooms']

# Feature Scaling
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X = df.drop('Price', axis=1)
y = df['Price']

X_scaled = scaler.fit_transform(X)`} />
              </section>
            )}

            {activeSection === 'modeling' && (
              <section id="modeling">
                <SectionHeader 
                  icon={Cpu} 
                  title="Model Development" 
                  subtitle="We compare three different regression algorithms: Linear Regression (baseline), Random Forest (ensemble), and XGBoost (gradient boosting)."
                />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  {[
                    { name: 'Linear Regression', type: 'Parametric', strength: 'Interpretability', color: 'slate' },
                    { name: 'Random Forest', type: 'Ensemble', strength: 'Non-linear patterns', color: 'indigo' },
                    { name: 'XGBoost', type: 'Boosting', strength: 'High Accuracy', color: 'rose' },
                  ].map((m, i) => (
                    <div key={i} className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
                      <h4 className="font-bold text-white mb-1">{m.name}</h4>
                      <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-4">{m.type}</p>
                      <div className="text-xs text-slate-400">
                        <span className="text-slate-500">Strength:</span> {m.strength}
                      </div>
                    </div>
                  ))}
                </div>

                <CodeBlock code={`from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb

# Split data
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# 1. Linear Regression
lr = LinearRegression()
lr.fit(X_train, y_train)

# 2. Random Forest
rf = RandomForestRegressor(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)

# 3. XGBoost
xgb_model = xgb.XGBRegressor(objective='reg:squarederror', n_estimators=100)
xgb_model.fit(X_train, y_train)`} />
              </section>
            )}

            {activeSection === 'evaluation' && (
              <section id="evaluation">
                <SectionHeader 
                  icon={BarChart3} 
                  title="Model Evaluation" 
                  subtitle="Comparing models using Root Mean Squared Error (RMSE) and R-squared (R²) scores to determine the best predictor."
                />

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                  <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">R² Score Comparison</h3>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={MODEL_PERFORMANCE}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                          <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                          <YAxis domain={[0, 1]} stroke="#64748b" fontSize={10} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px' }}
                          />
                          <Bar dataKey="r2" radius={[4, 4, 0, 0]}>
                            {MODEL_PERFORMANCE.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Feature Importance (XGBoost)</h3>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={FEATURE_IMPORTANCE}>
                          <PolarGrid stroke="#1e293b" />
                          <PolarAngleAxis dataKey="name" stroke="#64748b" fontSize={10} />
                          <Radar name="Importance" dataKey="importance" stroke="#6366f1" fill="#6366f1" fillOpacity={0.5} />
                        </RadarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                <CodeBlock code={`from sklearn.metrics import mean_squared_error, r2_score

def evaluate(model, X_test, y_test):
    preds = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, preds))
    r2 = r2_score(y_test, preds)
    return rmse, r2

# Results
for name, model in [('LR', lr), ('RF', rf), ('XGB', xgb_model)]:
    rmse, r2 = evaluate(model, X_test, y_test)
    print(f"{name} -> RMSE: {rmse:.4f}, R2: {r2:.4f}")`} />
              </section>
            )}

            {activeSection === 'prediction' && (
              <section id="prediction">
                <SectionHeader 
                  icon={Play} 
                  title="Live Prediction" 
                  subtitle="Test the model with your own inputs. This uses the weights derived from our XGBoost training to estimate house value."
                />

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 space-y-6">
                    <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {CALIFORNIA_STATS.slice(0, 4).map((stat) => (
                          <div key={stat.name} className="space-y-3">
                            <div className="flex justify-between items-center">
                              <label className="text-sm font-bold text-slate-300">{stat.label}</label>
                              <span className="text-xs font-mono text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded">
                                {predictionInputs[stat.name as keyof typeof predictionInputs]}
                              </span>
                            </div>
                            <input 
                              type="range" 
                              min={stat.min} 
                              max={stat.max} 
                              step={(stat.max - stat.min) / 100}
                              value={predictionInputs[stat.name as keyof typeof predictionInputs]}
                              onChange={(e) => setPredictionInputs(prev => ({ ...prev, [stat.name]: parseFloat(e.target.value) }))}
                              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                            />
                            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                              <span>{stat.min}</span>
                              <span>{stat.max}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="p-6 rounded-2xl bg-indigo-500/5 border border-indigo-500/20">
                      <h4 className="font-bold text-indigo-400 mb-2 flex items-center gap-2">
                        <Info size={16} /> How it works
                      </h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        The prediction is calculated using a simplified version of our regression model. 
                        <strong> Median Income</strong> has the highest positive correlation, while <strong>Avg Occupancy</strong> 
                        generally tends to decrease value in this specific dataset.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="p-8 rounded-3xl bg-gradient-to-br from-indigo-600 to-purple-700 text-white shadow-2xl shadow-indigo-500/20 flex flex-col items-center justify-center text-center">
                      <p className="text-xs font-bold uppercase tracking-widest opacity-70 mb-2">Estimated Value</p>
                      <h2 className="text-6xl font-black mb-2">${predictedPrice}k</h2>
                      <p className="text-sm opacity-80">Based on XGBoost Model</p>
                      
                      <div className="w-full h-px bg-white/20 my-6" />
                      
                      <div className="grid grid-cols-2 gap-4 w-full">
                        <div className="text-left">
                          <p className="text-[10px] opacity-60 uppercase font-bold">Confidence</p>
                          <p className="text-lg font-bold">83.4%</p>
                        </div>
                        <div className="text-left">
                          <p className="text-[10px] opacity-60 uppercase font-bold">Error Margin</p>
                          <p className="text-lg font-bold">±$47k</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
                      <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Python Inference Code</h4>
                      <pre className="text-[10px] font-mono text-slate-400 bg-slate-950 p-3 rounded-lg overflow-x-auto">
                        <code>{`new_data = np.array([[3.8, 28, 5.4, 1.0, 1425, 3.0, 35, -119]])
new_data_scaled = scaler.transform(new_data)
prediction = xgb_model.predict(new_data_scaled)
print(f"Predicted Price: \${prediction[0]:.2f}k")`}</code>
                      </pre>
                    </div>
                  </div>
                </div>
              </section>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Mobile Nav Overlay */}
      <div className="lg:hidden fixed bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2 p-2 rounded-2xl bg-slate-900/90 border border-slate-800 backdrop-blur-xl z-50 shadow-2xl">
        {sections.slice(0, 4).map((s) => (
          <button
            key={s.id}
            onClick={() => setActiveSection(s.id)}
            className={cn(
              "p-3 rounded-xl transition-colors",
              activeSection === s.id ? "bg-indigo-500 text-white" : "text-slate-400"
            )}
          >
            <s.icon size={20} />
          </button>
        ))}
        <div className="w-px h-6 bg-slate-800 mx-1" />
        <button onClick={() => setActiveSection('prediction')} className="p-3 rounded-xl bg-indigo-500 text-white">
          <Play size={20} />
        </button>
      </div>
    </div>
  );
}
